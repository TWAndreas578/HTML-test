from django.urls import path
from . import views

urlpatterns = [
    path('', views.admin_home, name='admin_home'),
    path('categories/', views.category_management, name='category_management'),
    path('projects/', views.project_management, name='project_management'),
    path('judges/', views.judge_management, name='judge_management'),
    path('judges/check-username/', views.check_judge_username, name='check_judge_username'),
    path('permissions/', views.permission_management, name='permission_management'),
    path('scores/', views.score_status, name='score_status'),
]
