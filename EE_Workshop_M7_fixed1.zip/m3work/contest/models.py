import uuid
from pathlib import Path
from django.db import models


def upload_group_icon(instance, filename: str) -> str:
    suffix = Path(filename).suffix.lower() or '.png'
    return f'group_icons/{uuid.uuid4()}{suffix}'


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    sort_order = models.PositiveSmallIntegerField(unique=True)
    icon = models.ImageField(upload_to=upload_group_icon, blank=True, null=True)
    icon_original_filename = models.CharField(max_length=255, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['sort_order', 'id']
        verbose_name = '組別'
        verbose_name_plural = '組別'

    def __str__(self) -> str:
        return self.name


class Project(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='projects')
    title = models.CharField(max_length=255)
    unit = models.CharField(max_length=100)
    participants = models.CharField(max_length=255)
    display_order = models.PositiveIntegerField(default=1)

    class Meta:
        ordering = ['category__sort_order', 'display_order', 'id']
        unique_together = [('category', 'display_order')]
        verbose_name = '作品'
        verbose_name_plural = '作品'

    def __str__(self) -> str:
        return self.title
