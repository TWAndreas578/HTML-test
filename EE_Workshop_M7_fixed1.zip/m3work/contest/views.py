from io import BytesIO

from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from openpyxl import load_workbook

from accounts.forms import JudgeForm
from .forms import CategoryForm, ProjectForm
from .models import Category, Project
from scoring.models import JudgeCategoryPermission, ManualProjectExclusion, GroupSubmission, Score
from scoring.rules import RuleEngine
from system.models import SystemSetting

MAX_PROJECTS_PER_CATEGORY = 120


def admin_required(view_func):
    @login_required
    def wrapper(request, *args, **kwargs):
        if not request.user.is_admin_role:
            return render(request, 'accounts/permission_denied.html', status=403)
        return view_func(request, *args, **kwargs)
    return wrapper


def _normalize_project_orders(category, ordered_ids=None):
    projects = list(category.projects.order_by('display_order', 'id'))
    if ordered_ids is not None:
        by_id = {p.id: p for p in projects}
        projects = [by_id[i] for i in ordered_ids if i in by_id]
    # Avoid the unique(category, display_order) constraint while reordering.
    for index, project in enumerate(projects, start=1):
        Project.objects.filter(pk=project.pk).update(display_order=1000 + index)
    for index, project in enumerate(projects, start=1):
        Project.objects.filter(pk=project.pk).update(display_order=index)


def _place_project(project, category, position):
    ids = list(category.projects.exclude(pk=project.pk).order_by('display_order', 'id').values_list('id', flat=True))
    position = max(1, min(position, len(ids) + 1))
    ids.insert(position - 1, project.pk)
    _normalize_project_orders(category, ids)


@admin_required
def admin_home(request):
    setting = SystemSetting.load()
    errors = {}
    saved = False
    if request.method == 'POST':
        header_title = request.POST.get('header_title', '').strip()
        judge_home_title = request.POST.get('judge_home_title', '').strip()
        if not header_title:
            errors['header_title'] = '系統 Header 標題不可空白。'
        elif len(header_title) > 50:
            errors['header_title'] = '系統 Header 標題最多 50 個字。'
        if not judge_home_title:
            errors['judge_home_title'] = '評審首頁標題不可空白。'
        elif len(judge_home_title) > 50:
            errors['judge_home_title'] = '評審首頁標題最多 50 個字。'
        if not errors:
            setting.header_title = header_title
            setting.judge_home_title = judge_home_title
            setting.save(update_fields=['header_title', 'judge_home_title', 'updated_at'])
            saved = True
    return render(request, 'admin_panel/home.html', {
        'setting': setting,
        'errors': errors,
        'saved': saved,
    })


@admin_required
def category_management(request):
    categories = list(Category.objects.all())
    create_form = CategoryForm(prefix='create')
    edit_forms = {category.id: CategoryForm(instance=category, prefix=f'edit-{category.id}') for category in categories}
    open_modal_id = None
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'create':
            create_form = CategoryForm(request.POST, request.FILES, prefix='create')
            if create_form.is_valid():
                create_form.save()
                return redirect('category_management')
            open_modal_id = 'createCategoryModal'
        elif action == 'edit':
            category = get_object_or_404(Category, pk=request.POST.get('category_id'))
            form = CategoryForm(request.POST, request.FILES, instance=category, prefix=f'edit-{category.id}')
            edit_forms[category.id] = form
            if form.is_valid():
                form.save()
                return redirect('category_management')
            open_modal_id = f'editCategoryModal{category.id}'
        elif action == 'delete':
            category = get_object_or_404(Category, pk=request.POST.get('category_id'))
            icon_name = category.icon.name if category.icon else ''
            icon_storage = category.icon.storage if category.icon else None
            category.delete()
            if icon_name and icon_storage:
                icon_storage.delete(icon_name)
            return redirect('category_management')
    categories = list(Category.objects.all())
    for category in categories:
        edit_forms.setdefault(category.id, CategoryForm(instance=category, prefix=f'edit-{category.id}'))
    return render(request, 'admin_panel/category_management.html', {
        'category_rows': [(c, edit_forms[c.id]) for c in categories],
        'create_form': create_form,
        'open_modal_id': open_modal_id,
    })


def _recalculate_category_submission_statuses(category):
    RuleEngine.recalculate_category_submissions(category)


def _mark_submitted_judges_pending_for_new_projects(category, projects):
    # Kept as a compatibility wrapper for existing call sites. The status is no
    # longer one-way event state; it is reconciled from current requirements.
    if list(projects):
        _recalculate_category_submission_statuses(category)


@admin_required
def project_management(request):
    categories = list(Category.objects.all())
    selected_id = request.GET.get('category') or request.POST.get('category_id')
    selected_category = None
    if selected_id:
        selected_category = next((c for c in categories if str(c.id) == str(selected_id)), None)
    if not selected_category and categories:
        selected_category = categories[0]

    create_form = ProjectForm(prefix='create', category=selected_category)
    edit_forms = {}
    open_modal_id = None
    import_preview = request.session.get('project_import_preview')
    import_error = None

    if selected_category:
        edit_forms = {
            p.id: ProjectForm(instance=p, prefix=f'edit-{p.id}', category=selected_category)
            for p in selected_category.projects.order_by('display_order', 'id')
        }

    if request.method == 'POST' and selected_category:
        action = request.POST.get('action')
        if action == 'create':
            create_form = ProjectForm(request.POST, prefix='create', category=selected_category)
            if selected_category.projects.count() >= MAX_PROJECTS_PER_CATEGORY:
                create_form.add_error(None, '每個組別最多只能有 120 件作品。')
                open_modal_id = 'createProjectModal'
            elif create_form.is_valid():
                with transaction.atomic():
                    project = create_form.save(commit=False)
                    project.category = selected_category
                    project.display_order = selected_category.projects.count() + 1
                    project.save()
                    _place_project(project, selected_category, create_form.cleaned_data['insert_position'])
                    _mark_submitted_judges_pending_for_new_projects(selected_category, [project])
                return redirect(f'/admin-panel/projects/?category={selected_category.id}')
            else:
                open_modal_id = 'createProjectModal'

        elif action == 'edit':
            project = get_object_or_404(Project, pk=request.POST.get('project_id'), category=selected_category)
            form = ProjectForm(request.POST, instance=project, prefix=f'edit-{project.id}', category=selected_category)
            edit_forms[project.id] = form
            if form.is_valid():
                with transaction.atomic():
                    project = form.save()
                    _place_project(project, selected_category, form.cleaned_data['insert_position'])
                    _recalculate_category_submission_statuses(selected_category)
                return redirect(f'/admin-panel/projects/?category={selected_category.id}')
            open_modal_id = f'editProjectModal{project.id}'

        elif action == 'delete':
            project = get_object_or_404(Project, pk=request.POST.get('project_id'), category=selected_category)
            with transaction.atomic():
                project.delete()
                _normalize_project_orders(selected_category)
                _recalculate_category_submission_statuses(selected_category)
            return redirect(f'/admin-panel/projects/?category={selected_category.id}')

        elif action == 'preview_import':
            upload = request.FILES.get('excel_file')
            if not upload or not upload.name.lower().endswith('.xlsx'):
                import_error = '請選擇 .xlsx Excel 檔案。'
                open_modal_id = 'importProjectModal'
            else:
                try:
                    workbook = load_workbook(filename=BytesIO(upload.read()), read_only=True, data_only=True)
                    sheet = workbook.active
                    rows = []
                    errors = []
                    blank_streak = 0
                    for excel_row, values in enumerate(sheet.iter_rows(min_row=2, max_col=3, values_only=True), start=2):
                        cleaned = [('' if v is None else str(v).strip()) for v in values]
                        if not any(cleaned):
                            blank_streak += 1
                            if blank_streak >= 2:
                                break
                            continue
                        blank_streak = 0
                        missing = [label for label, value in zip(['作品名稱', '單位', '參賽者'], cleaned) if not value]
                        row = {'excel_row': excel_row, 'title': cleaned[0], 'unit': cleaned[1], 'participants': cleaned[2], 'error': ''}
                        if missing:
                            row['error'] = f"缺少：{'、'.join(missing)}"
                            errors.append(excel_row)
                        rows.append(row)
                    if not rows:
                        import_error = 'Excel 中沒有可匯入的作品資料。'
                        open_modal_id = 'importProjectModal'
                    elif selected_category.projects.count() + len(rows) > MAX_PROJECTS_PER_CATEGORY:
                        import_error = f'匯入後將超過每組 120 件作品的上限。目前已有 {selected_category.projects.count()} 件。'
                        open_modal_id = 'importProjectModal'
                    else:
                        import_preview = {
                            'category_id': selected_category.id,
                            'filename': upload.name,
                            'rows': rows,
                            'has_errors': bool(errors),
                        }
                        request.session['project_import_preview'] = import_preview
                        open_modal_id = 'importPreviewModal'
                except Exception:
                    import_error = 'Excel 檔案無法讀取，請確認檔案格式與內容。'
                    open_modal_id = 'importProjectModal'

        elif action == 'confirm_import':
            preview = request.session.get('project_import_preview')
            if not preview or preview.get('category_id') != selected_category.id or preview.get('has_errors'):
                import_error = '匯入預覽已失效或仍有錯誤，請重新選擇檔案。'
                open_modal_id = 'importProjectModal'
            else:
                rows = preview.get('rows', [])
                if selected_category.projects.count() + len(rows) > MAX_PROJECTS_PER_CATEGORY:
                    import_error = '匯入後將超過每組 120 件作品的上限。'
                    open_modal_id = 'importProjectModal'
                else:
                    with transaction.atomic():
                        next_order = selected_category.projects.count() + 1
                        created_projects = Project.objects.bulk_create([
                            Project(category=selected_category, title=r['title'], unit=r['unit'], participants=r['participants'], display_order=next_order+i)
                            for i, r in enumerate(rows)
                        ])
                        _mark_submitted_judges_pending_for_new_projects(selected_category, created_projects)
                    request.session.pop('project_import_preview', None)
                    return redirect(f'/admin-panel/projects/?category={selected_category.id}')

        elif action == 'cancel_import':
            request.session.pop('project_import_preview', None)
            return redirect(f'/admin-panel/projects/?category={selected_category.id}')

    projects = list(selected_category.projects.order_by('display_order', 'id')) if selected_category else []
    for project in projects:
        edit_forms.setdefault(project.id, ProjectForm(instance=project, prefix=f'edit-{project.id}', category=selected_category))
    if import_preview and selected_category and import_preview.get('category_id') != selected_category.id:
        import_preview = None

    return render(request, 'admin_panel/project_management.html', {
        'categories': categories,
        'selected_category': selected_category,
        'projects': projects,
        'project_rows': [(p, edit_forms[p.id]) for p in projects],
        'create_form': create_form,
        'open_modal_id': open_modal_id,
        'import_preview': import_preview,
        'import_error': import_error,
        'max_projects': MAX_PROJECTS_PER_CATEGORY,
    })


@admin_required
def judge_management(request):
    User = get_user_model()
    judges = User.objects.filter(role=User.ROLE_JUDGE).order_by('username')
    create_form = JudgeForm(prefix='create')
    edit_forms = {judge.id: JudgeForm(instance=judge, prefix=f'edit-{judge.id}', is_edit=True) for judge in judges}
    open_modal_id = None
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'create':
            create_form = JudgeForm(request.POST, prefix='create')
            if create_form.is_valid():
                create_form.save()
                return redirect('judge_management')
            open_modal_id = 'createJudgeModal'
        elif action == 'edit':
            judge = get_object_or_404(User, pk=request.POST.get('judge_id'), role=User.ROLE_JUDGE)
            form = JudgeForm(request.POST, instance=judge, prefix=f'edit-{judge.id}', is_edit=True)
            edit_forms[judge.id] = form
            if form.is_valid():
                updated_judge = form.save()
                for permission in updated_judge.category_permissions.select_related('category'):
                    RuleEngine.recalculate_submission_status(updated_judge, permission.category)
                return redirect('judge_management')
            open_modal_id = f'editJudgeModal{judge.id}'
        elif action == 'delete':
            judge = get_object_or_404(User, pk=request.POST.get('judge_id'), role=User.ROLE_JUDGE)
            judge.delete()
            return redirect('judge_management')
    return render(request, 'admin_panel/judge_management.html', {
        'judges': judges,
        'judge_rows': [(j, edit_forms[j.id]) for j in judges],
        'create_form': create_form,
        'open_modal_id': open_modal_id,
    })


@admin_required
def check_judge_username(request):
    username = request.GET.get('username', '').strip().lower()
    exclude_id = request.GET.get('exclude_id')
    User = get_user_model()
    qs = User.objects.filter(username=username)
    if exclude_id:
        qs = qs.exclude(pk=exclude_id)
    return JsonResponse({'exists': bool(username) and qs.exists(), 'valid_format': bool(username)})


@admin_required
def permission_management(request):
    User = get_user_model()
    judges = list(User.objects.filter(role=User.ROLE_JUDGE).order_by('username'))
    categories = list(Category.objects.all())
    selected_judge_id = request.GET.get('judge') or request.POST.get('judge_id')
    selected_judge = next((j for j in judges if str(j.id) == str(selected_judge_id)), None)
    if not selected_judge and judges:
        selected_judge = judges[0]

    if request.method == 'POST':
        if not selected_judge:
            return JsonResponse({'ok': False, 'error': '找不到評審。'}, status=404)
        action = request.POST.get('action')
        if action == 'toggle_category':
            category = get_object_or_404(Category, pk=request.POST.get('category_id'))
            enabled = request.POST.get('enabled') == 'true'
            with transaction.atomic():
                if enabled:
                    JudgeCategoryPermission.objects.get_or_create(judge=selected_judge, category=category)
                    RuleEngine.recalculate_submission_status(selected_judge, category)
                else:
                    JudgeCategoryPermission.objects.filter(judge=selected_judge, category=category).delete()
            return JsonResponse({'ok': True})

        if action == 'toggle_exclusion':
            project = get_object_or_404(Project, pk=request.POST.get('project_id'))
            if not JudgeCategoryPermission.objects.filter(judge=selected_judge, category=project.category).exists():
                return JsonResponse({'ok': False, 'error': '評審沒有此組別權限。'}, status=400)
            if (project.unit or '').strip().casefold() == (selected_judge.unit or '').strip().casefold():
                return JsonResponse({'ok': False, 'error': '同單位作品由系統自動排除。'}, status=400)
            excluded = request.POST.get('excluded') == 'true'
            with transaction.atomic():
                if excluded:
                    ManualProjectExclusion.objects.update_or_create(
                        judge=selected_judge, project=project, defaults={'is_excluded': True}
                    )
                else:
                    ManualProjectExclusion.objects.filter(judge=selected_judge, project=project).delete()
                RuleEngine.recalculate_submission_status(selected_judge, project.category)
            return JsonResponse({'ok': True})
        return JsonResponse({'ok': False, 'error': '未知操作。'}, status=400)

    permission_ids = set()
    selected_category = None
    project_rows = []
    permitted_categories = []
    if selected_judge:
        permission_ids = set(JudgeCategoryPermission.objects.filter(judge=selected_judge).values_list('category_id', flat=True))
        permitted_categories = [c for c in categories if c.id in permission_ids]
        selected_category_id = request.GET.get('category')
        selected_category = next((c for c in permitted_categories if str(c.id) == str(selected_category_id)), None)
        if not selected_category and permitted_categories:
            selected_category = permitted_categories[0]
        if selected_category:
            excluded_ids = set(ManualProjectExclusion.objects.filter(
                judge=selected_judge, project__category=selected_category, is_excluded=True
            ).values_list('project_id', flat=True))
            judge_unit = (selected_judge.unit or '').strip().casefold()
            for project in selected_category.projects.order_by('display_order', 'id'):
                same_unit = (project.unit or '').strip().casefold() == judge_unit
                project_rows.append({
                    'project': project,
                    'same_unit': same_unit,
                    'excluded': project.id in excluded_ids,
                })

    return render(request, 'admin_panel/permission_management.html', {
        'judges': judges,
        'categories': categories,
        'selected_judge': selected_judge,
        'permission_ids': permission_ids,
        'permitted_categories': permitted_categories,
        'selected_category': selected_category,
        'project_rows': project_rows,
    })


@admin_required
def score_status(request):
    categories = list(Category.objects.all())
    selected_id = request.GET.get('category') or request.POST.get('category_id')
    selected_category = next((c for c in categories if str(c.id) == str(selected_id)), None)
    if not selected_category and categories:
        selected_category = categories[0]

    if request.method == 'POST' and selected_category:
        action = request.POST.get('action')
        if action == 'unlock':
            judge = get_object_or_404(get_user_model(), pk=request.POST.get('judge_id'))
            submission = get_object_or_404(
                GroupSubmission,
                judge=judge,
                category=selected_category,
            )
            submission.is_locked = False
            submission.save(update_fields=['is_locked'])
            return redirect(f'/admin-panel/scores/?category={selected_category.id}')

    judge_columns = []
    project_rows = []
    if selected_category:
        RuleEngine.recalculate_category_submissions(selected_category)
        permissions = list(
            JudgeCategoryPermission.objects
            .filter(category=selected_category)
            .select_related('judge')
            .order_by('judge__unit', 'judge__display_name', 'judge__username')
        )
        submissions = {
            submission.judge_id: submission
            for submission in GroupSubmission.objects.filter(
                category=selected_category,
                judge_id__in=[permission.judge_id for permission in permissions],
            )
        }
        exclusion_pairs = set(
            ManualProjectExclusion.objects.filter(
                project__category=selected_category,
                judge_id__in=[permission.judge_id for permission in permissions],
                is_excluded=True,
            ).values_list('judge_id', 'project_id')
        )
        scores = {
            (score.judge_id, score.project_id): score.grade
            for score in Score.objects.filter(
                project__category=selected_category,
                judge_id__in=[permission.judge_id for permission in permissions],
            )
        }

        for permission in permissions:
            judge = permission.judge
            submission = submissions.get(judge.id)
            if not submission:
                display_status = '未提交'
            elif submission.status == GroupSubmission.STATUS_PENDING:
                display_status = '待評分'
            elif not submission.is_locked:
                display_status = '未提交'
            else:
                display_status = '已提交'
            judge_columns.append({
                'judge': judge,
                'submission': submission,
                'display_status': display_status,
                'show_scores': bool(
                    submission
                    and submission.status == GroupSubmission.STATUS_SUBMITTED
                    and submission.is_locked
                ),
                'can_unlock': bool(submission and submission.is_locked),
            })

        for project in selected_category.projects.order_by('display_order', 'id'):
            cells = []
            project_unit = (project.unit or '').strip().casefold()
            for column in judge_columns:
                judge = column['judge']
                same_unit = project_unit == (judge.unit or '').strip().casefold()
                manually_excluded = (judge.id, project.id) in exclusion_pairs
                unavailable = same_unit or manually_excluded
                grade = ''
                if column['show_scores'] and not unavailable:
                    grade = scores.get((judge.id, project.id), '')
                cells.append({
                    'grade': grade,
                    'unavailable': unavailable,
                })
            project_rows.append({'project': project, 'cells': cells})

    return render(request, 'admin_panel/score_status.html', {
        'categories': categories,
        'selected_category': selected_category,
        'judge_columns': judge_columns,
        'project_rows': project_rows,
    })
