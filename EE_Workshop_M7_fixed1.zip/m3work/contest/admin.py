from django.contrib import admin
from .models import Category, Project


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'sort_order', 'is_active')
    ordering = ('sort_order',)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('category', 'display_order', 'unit', 'title', 'participants')
    list_filter = ('category', 'unit')
    ordering = ('category__sort_order', 'display_order')
