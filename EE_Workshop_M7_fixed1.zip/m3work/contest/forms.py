from pathlib import Path

from django import forms
from django.core.exceptions import ValidationError

from .models import Category, Project


MAX_ICON_SIZE = 100 * 1024
ALLOWED_ICON_SUFFIXES = {'.png', '.jpg', '.jpeg'}


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'sort_order', 'icon']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100, 'autocomplete': 'off'}),
            'sort_order': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 99}),
            'icon': forms.ClearableFileInput(attrs={
                'class': 'form-control',
                'accept': '.png,.jpg,.jpeg,image/png,image/jpeg',
            }),
        }
        labels = {
            'name': '組別名稱',
            'sort_order': '排序',
            'icon': '組別圖示',
        }

    def clean_name(self):
        name = self.cleaned_data['name'].strip()
        qs = Category.objects.filter(name__iexact=name)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError('組別名稱已存在。')
        return name

    def clean_sort_order(self):
        sort_order = self.cleaned_data['sort_order']
        if sort_order < 1 or sort_order > 99:
            raise ValidationError('排序必須介於 1 到 99。')
        qs = Category.objects.filter(sort_order=sort_order)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError('此排序已被其他組別使用。')
        return sort_order

    def clean_icon(self):
        icon = self.cleaned_data.get('icon')
        if not icon:
            return icon

        suffix = Path(icon.name).suffix.lower()
        if suffix not in ALLOWED_ICON_SUFFIXES:
            raise ValidationError('圖示只接受 PNG、JPG 或 JPEG。')
        if icon.size > MAX_ICON_SIZE:
            raise ValidationError('圖示檔案不可超過 100 KB。')
        content_type = getattr(icon, 'content_type', '')
        if content_type and content_type not in {'image/png', 'image/jpeg'}:
            raise ValidationError('圖示格式不正確，請使用 PNG 或 JPG。')
        return icon

    def save(self, commit=True):
        category = super().save(commit=False)
        new_icon = self.cleaned_data.get('icon')
        clear_icon = new_icon is False
        old_icon_name = ''
        old_storage = None

        if category.pk:
            old = Category.objects.filter(pk=category.pk).only('icon').first()
            if old and old.icon:
                old_icon_name = old.icon.name
                old_storage = old.icon.storage

        if clear_icon:
            category.icon_original_filename = ''
        elif new_icon:
            category.icon_original_filename = new_icon.name

        if commit:
            category.save()
            should_delete_old = old_icon_name and (
                clear_icon or (new_icon and category.icon.name != old_icon_name)
            )
            if should_delete_old and old_storage:
                old_storage.delete(old_icon_name)
        return category


class ProjectForm(forms.ModelForm):
    insert_position = forms.IntegerField(
        min_value=1,
        required=False,
        label='插入位置',
        widget=forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
    )

    class Meta:
        model = Project
        fields = ['title', 'unit', 'participants']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 255, 'autocomplete': 'off'}),
            'unit': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 100, 'autocomplete': 'off'}),
            'participants': forms.TextInput(attrs={'class': 'form-control', 'maxlength': 255, 'autocomplete': 'off'}),
        }
        labels = {
            'title': '作品名稱',
            'unit': '單位',
            'participants': '參賽者',
        }

    def __init__(self, *args, category=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.category = category or getattr(self.instance, 'category', None)
        count = self.category.projects.count() if self.category and self.category.pk else 0
        max_position = max(1, count + (0 if self.instance.pk else 1))
        self.fields['insert_position'].widget.attrs['max'] = max_position
        if not self.is_bound:
            self.fields['insert_position'].initial = self.instance.display_order if self.instance.pk else count + 1

    def clean_title(self):
        value = self.cleaned_data['title'].strip()
        if not value:
            raise ValidationError('請輸入作品名稱。')
        return value

    def clean_unit(self):
        value = self.cleaned_data['unit'].strip()
        if not value:
            raise ValidationError('請輸入單位。')
        return value

    def clean_participants(self):
        value = self.cleaned_data['participants'].strip()
        if not value:
            raise ValidationError('請輸入參賽者。')
        return value

    def clean_insert_position(self):
        position = self.cleaned_data.get('insert_position')
        count = self.category.projects.count() if self.category and self.category.pk else 0
        max_position = max(1, count + (0 if self.instance.pk else 1))
        if position is None:
            return self.instance.display_order if self.instance.pk else count + 1
        if position < 1 or position > max_position:
            raise ValidationError(f'插入位置必須介於 1 到 {max_position}。')
        return position
