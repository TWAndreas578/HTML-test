# EE Workshop 評分系統 — Milestone 4

## 本版本內容
- 保留 M2 fixed-6：評審帳號管理、完整本機 Bootstrap 5 與 Bootstrap Icons。
- 新增組別管理：新增、編輯、刪除。
- 組別名稱不可重複（不分大小寫）。
- 排序限定 1–99，且不可重複。
- 圖示接受 PNG/JPG/JPEG，檔案上限 100 KB；建議 1:1、128 × 128 px。
- 圖示以 UUID 檔名存放，保留原始檔名供管理頁顯示。
- 更換或移除圖示後會刪除舊檔。
- 刪除組別使用確認 Dialog，並連動刪除作品、評分、權限與提交紀錄。

## 執行
```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py create_default_admin
python manage.py runserver
```

預設管理員：`admin / admin12345`


## Milestone 4
- 作品管理：手動新增、編輯、刪除與插入排序。
- Excel .xlsx 匯入預覽與欄位驗證。
- 每組最多 120 件作品。

## M4 修正版2
- 組別管理編輯 Dialog 已移除自訂「移除目前圖示」選項。
- 保留 Django 檔案欄位內建的「清除」選項，勾選後會移除目前圖示並刪除舊圖檔。
- Excel 上傳仍只在請求期間解析，不永久保存原始 Excel 檔案。

## Milestone 6
- 評審首頁顯示授權組別、進度與未提交／已提交／待評分狀態。
- 評分頁支援 A/B/C 評分、localStorage 暫存、背景同步、手動儲存草稿與提交鎖定。
- 同單位及管理員手動排除作品不可評分。

## M6 fixed1 修正
- 未完成所有必要作品時，「提交評分」保持停用；完成後自動啟用。
- 手動新增或 Excel 匯入需要評分的新作品後，已提交評審的組別轉為「待評分」並維持鎖定。
- 後台首頁可修改系統 Header 標題與評審首頁標題。
- 評審首頁組別圖示調整為 64×64 px；管理員表格與權限頁圖示調整為 48×48 px。
- 本版新增 system migration 0002，更新後請執行 `python manage.py migrate`。

## M6 fixed2 狀態校正
- 已提交組別的狀態改為依「目前必要作品」與「現有分數」雙向重算。
- 新增、匯入、編輯、刪除作品後會立即重算。
- 修改評審單位、調整組別權限、變更手動排除後會立即重算。
- 評審首頁與評分頁載入時會再次校正，避免漏掉異動入口。
- 刪除造成缺分的作品後可由「待評分」恢復「已提交」。
- 作品由同單位改為不同單位時，若尚未評分會轉為「待評分」。

## Milestone 7：評分狀況查看

- 管理員可依組別查看作品 × 評審評分矩陣。
- 評審欄顯示單位、姓名、未提交／已提交／待評分狀態。
- 僅已提交且鎖定的評審顯示 A／B／C 分數。
- 未提交、待評分與解鎖中的評審欄位保持空白。
- 同單位與手動排除作品以灰色空白儲存格顯示。
- 表格支援水平、垂直捲動，並凍結表頭及左側作品欄。
- 管理員可透過 Dialog 解鎖評審；原分數保留，評審可修改後重新提交。


## M7 fixed1
- Fixed-width 260px project-name columns with ellipsis in project management, score status, and judge scoring pages.
- Judge group cards are gray only while locked; unlocked submitted groups return to blue and display 未提交.
- Excel export remains scheduled for M8.
