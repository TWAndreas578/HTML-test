from django.urls import path
from .views import system_settings_page

urlpatterns = [
    path('settings/', system_settings_page, name='system_settings'),
]
