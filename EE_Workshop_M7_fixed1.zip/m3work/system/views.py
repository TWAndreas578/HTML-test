from contest.views import admin_required
from django.shortcuts import render


@admin_required
def system_settings_page(request):
    return render(request, 'admin_panel/system_settings.html')
