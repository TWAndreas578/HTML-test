from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('system', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='systemsetting',
            name='judge_home_title',
            field=models.CharField(default='評審首頁', max_length=50),
        ),
    ]
