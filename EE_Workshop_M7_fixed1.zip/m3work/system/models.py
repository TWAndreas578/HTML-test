import uuid
from pathlib import Path
from django.db import models


def upload_logo(instance, filename: str) -> str:
    suffix = Path(filename).suffix.lower() or '.png'
    return f'logos/{uuid.uuid4()}{suffix}'


def upload_favicon(instance, filename: str) -> str:
    suffix = Path(filename).suffix.lower() or '.ico'
    return f'favicons/{uuid.uuid4()}{suffix}'


class SystemSetting(models.Model):
    header_title = models.CharField(max_length=255, default='EE Workshop 評分系統')
    judge_home_title = models.CharField(max_length=50, default='評審首頁')
    header_bg_color = models.CharField(max_length=20, default='#0C46FE')
    header_text_color = models.CharField(max_length=20, default='#FFFFFF')
    logo = models.ImageField(upload_to=upload_logo, blank=True, null=True)
    logo_original_filename = models.CharField(max_length=255, blank=True)
    favicon = models.ImageField(upload_to=upload_favicon, blank=True, null=True)
    favicon_original_filename = models.CharField(max_length=255, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self) -> str:
        return self.header_title
