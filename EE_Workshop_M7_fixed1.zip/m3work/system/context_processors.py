from .models import SystemSetting


def system_settings(request):
    try:
        return {'system_setting': SystemSetting.load()}
    except Exception:
        return {'system_setting': None}
