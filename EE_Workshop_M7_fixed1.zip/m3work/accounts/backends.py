from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model


class LowercaseUsernameBackend(ModelBackend):
    """Authenticate username/password case-insensitively.

    Passwords are normalized to lower case before hashing/checking because the
    project specification defines judge/admin passwords as case-insensitive.
    """

    def authenticate(self, request, username=None, password=None, **kwargs):
        UserModel = get_user_model()
        if username is None:
            username = kwargs.get(UserModel.USERNAME_FIELD)
        if username is None or password is None:
            return None
        try:
            user = UserModel._default_manager.get(username=username.lower())
        except UserModel.DoesNotExist:
            UserModel().set_password(password.lower())
            return None
        if user.check_password(password.lower()) and self.user_can_authenticate(user):
            return user
        return None
