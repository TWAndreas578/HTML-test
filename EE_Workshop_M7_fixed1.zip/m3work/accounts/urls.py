from django.urls import path
from .views import LoginView, LogoutView, role_redirect

urlpatterns = [
    path('', role_redirect, name='role_redirect'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
]
