from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator
from django.db import models


alnum_validator = RegexValidator(
    regex=r'^[A-Za-z0-9]+$',
    message='只能輸入英文與數字',
)


class User(AbstractUser):
    ROLE_ADMIN = 'admin'
    ROLE_JUDGE = 'judge'
    ROLE_CHOICES = [
        (ROLE_ADMIN, 'Admin'),
        (ROLE_JUDGE, 'Judge'),
    ]

    # Do not ask for email when running createsuperuser.
    REQUIRED_FIELDS: list[str] = []

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_JUDGE)
    display_name = models.CharField('姓名', max_length=100, blank=True)
    unit = models.CharField('單位', max_length=100, blank=True)
    plain_password = models.CharField('密碼明碼', max_length=128, blank=True, default='')

    def save(self, *args, **kwargs):
        if self.username:
            self.username = self.username.lower()
        super().save(*args, **kwargs)

    def set_password(self, raw_password):
        """Passwords are case-insensitive by specification."""
        if raw_password is not None:
            raw_password = raw_password.lower()
        super().set_password(raw_password)

    @property
    def is_admin_role(self) -> bool:
        return self.role == self.ROLE_ADMIN

    @property
    def is_judge_role(self) -> bool:
        return self.role == self.ROLE_JUDGE

    def __str__(self) -> str:
        label = self.display_name or self.username
        if self.unit:
            return f'{self.username} / {self.unit} / {label}'
        return self.username
