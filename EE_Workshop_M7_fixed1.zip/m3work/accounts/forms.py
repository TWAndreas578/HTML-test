from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm


class LowercaseAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label='帳號')
    password = forms.CharField(label='密碼', widget=forms.PasswordInput)

    def clean_username(self):
        return self.cleaned_data['username'].lower()


class JudgeForm(forms.ModelForm):
    password = forms.CharField(
        label='密碼',
        required=True,
        widget=forms.TextInput(attrs={'autocomplete': 'off'}),
        help_text='至少 8 碼，只能使用英文與數字；不分大小寫。',
    )

    class Meta:
        model = get_user_model()
        fields = ['username', 'display_name', 'unit', 'password', 'is_active']
        labels = {
            'username': '帳號',
            'display_name': '姓名',
            'unit': '單位',
            'is_active': '狀態',
        }
        widgets = {
            'username': forms.TextInput(attrs={'autocomplete': 'off'}),
            'display_name': forms.TextInput(attrs={'autocomplete': 'off'}),
            'unit': forms.TextInput(attrs={'autocomplete': 'off'}),
        }

    def __init__(self, *args, **kwargs):
        self.is_edit = kwargs.pop('is_edit', False)
        super().__init__(*args, **kwargs)
        self.fields['is_active'].required = False
        self.fields['is_active'].help_text = '勾選代表啟用；取消勾選代表停用。'
        for name in ['username', 'display_name', 'unit', 'password']:
            self.fields[name].widget.attrs.update({'class': 'form-control'})
        self.fields['is_active'].widget.attrs.update({'class': 'form-check-input'})
        if self.is_edit:
            self.fields['username'].disabled = True
            self.fields['password'].required = False
            # Important: never show the stored Django password hash in the edit dialog.
            # Empty password means "do not change the current password".
            current_plain_password = getattr(self.instance, 'plain_password', '') or ''
            self.fields['password'].initial = current_plain_password
            self.initial['password'] = current_plain_password
            self.fields['password'].widget.attrs.pop('value', None)
            self.fields['password'].help_text = '目前密碼以明碼顯示；若清空後儲存，會保留原密碼。'

    def clean_username(self):
        username = self.cleaned_data['username'].lower().strip()
        if not username:
            raise forms.ValidationError('帳號不可空白')
        qs = get_user_model().objects.filter(username=username)
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError('帳號已存在')
        return username

    def clean_password(self):
        password = self.cleaned_data.get('password', '')
        if self.is_edit and password == '':
            return password
        normalized = password.lower().strip()
        import re
        if not re.match(r'^[a-z0-9]{8,}$', normalized):
            raise forms.ValidationError('密碼至少 8 碼，且只能使用英文與數字。')
        return normalized

    def clean_display_name(self):
        value = self.cleaned_data['display_name'].strip()
        if not value:
            raise forms.ValidationError('姓名不可空白')
        return value

    def clean_unit(self):
        value = self.cleaned_data['unit'].strip()
        if not value:
            raise forms.ValidationError('單位不可空白')
        return value

    def save(self, commit=True):
        # ModelForm would otherwise assign the plain password field directly to
        # user.password. Preserve the old hash when editing and the password
        # field is left blank.
        old_password_hash = None
        if self.is_edit and self.instance and self.instance.pk:
            UserModel = get_user_model()
            old_password_hash = UserModel.objects.only('password').get(pk=self.instance.pk).password
        user = super().save(commit=False)
        user.role = user.ROLE_JUDGE
        user.is_staff = False
        user.is_superuser = False
        password = self.cleaned_data.get('password')
        if password:
            user.set_password(password)
            user.plain_password = password
        elif self.is_edit and old_password_hash:
            user.password = old_password_hash
        if commit:
            user.save()
        return user
