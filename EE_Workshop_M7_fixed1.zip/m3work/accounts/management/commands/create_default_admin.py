from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = 'Create the default EE Workshop admin account if it does not exist.'

    def add_arguments(self, parser):
        parser.add_argument('--username', default='admin')
        parser.add_argument('--password', default='admin12345')

    def handle(self, *args, **options):
        User = get_user_model()
        username = options['username'].lower()
        password = options['password'].lower()
        user, created = User.objects.get_or_create(
            username=username,
            defaults={
                'role': User.ROLE_ADMIN,
                'is_staff': True,
                'is_superuser': True,
                'display_name': '管理員',
            },
        )
        user.role = User.ROLE_ADMIN
        user.is_staff = True
        user.is_superuser = True
        user.set_password(password)
        user.save()
        self.stdout.write(self.style.SUCCESS(f"Admin account ready: {username}"))
