from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('EE Workshop', {'fields': ('role', 'display_name', 'unit', 'is_active')}),
        ('權限', {'fields': ('is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('重要日期', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'role', 'display_name', 'unit', 'password1', 'password2'),
        }),
    )
    list_display = ('username', 'display_name', 'unit', 'role', 'is_active')
    list_filter = ('role', 'is_active')
    search_fields = ('username', 'display_name', 'unit')
    ordering = ('username',)
