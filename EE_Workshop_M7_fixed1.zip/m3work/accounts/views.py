from django.contrib.auth import views as auth_views
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.urls import reverse_lazy

from .forms import LowercaseAuthenticationForm


class LoginView(auth_views.LoginView):
    template_name = 'accounts/login.html'
    authentication_form = LowercaseAuthenticationForm
    redirect_authenticated_user = True


class LogoutView(auth_views.LogoutView):
    next_page = reverse_lazy('login')


@login_required
def role_redirect(request):
    if request.user.is_admin_role:
        return redirect('admin_home')
    return redirect('judge_home')
