from django.conf import settings
from django.db import models

from contest.models import Category, Project


class JudgeCategoryPermission(models.Model):
    judge = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='category_permissions')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='judge_permissions')

    class Meta:
        unique_together = [('judge', 'category')]


class ManualProjectExclusion(models.Model):
    judge = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='manual_exclusions')
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='manual_exclusions')
    is_excluded = models.BooleanField(default=True)

    class Meta:
        unique_together = [('judge', 'project')]


class Score(models.Model):
    SCORE_A = 'A'
    SCORE_B = 'B'
    SCORE_C = 'C'
    SCORE_CHOICES = [(SCORE_A, 'A'), (SCORE_B, 'B'), (SCORE_C, 'C')]
    SCORE_VALUE = {SCORE_A: 3, SCORE_B: 1, SCORE_C: 0}

    judge = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='scores')
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='scores')
    grade = models.CharField(max_length=1, choices=SCORE_CHOICES)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = [('judge', 'project')]

    @property
    def value(self) -> int:
        return self.SCORE_VALUE.get(self.grade, 0)


class GroupSubmission(models.Model):
    STATUS_SUBMITTED = 'submitted'
    STATUS_PENDING = 'pending'
    STATUS_CHOICES = [
        (STATUS_SUBMITTED, '已提交'),
        (STATUS_PENDING, '待評分'),
    ]

    judge = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='group_submissions')
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='submissions')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_SUBMITTED)
    submitted_at = models.DateTimeField(auto_now=True)
    is_locked = models.BooleanField(default=True)

    class Meta:
        unique_together = [('judge', 'category')]
