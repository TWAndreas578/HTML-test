from dataclasses import dataclass

from .models import ManualProjectExclusion, Score, GroupSubmission, JudgeCategoryPermission


@dataclass(frozen=True)
class EligibilityResult:
    can_score: bool
    reason: str = ''


class RuleEngine:
    """Single source of truth for scoring rules."""

    @staticmethod
    def project_eligibility(judge, project) -> EligibilityResult:
        if (project.unit or '').strip().casefold() == (judge.unit or '').strip().casefold():
            return EligibilityResult(False, 'same_unit')
        if ManualProjectExclusion.objects.filter(judge=judge, project=project, is_excluded=True).exists():
            return EligibilityResult(False, 'manual_exclusion')
        return EligibilityResult(True, '')

    @classmethod
    def required_projects(cls, judge, category):
        return [p for p in category.projects.all() if cls.project_eligibility(judge, p).can_score]

    @classmethod
    def progress(cls, judge, category) -> tuple[int, int]:
        required = cls.required_projects(judge, category)
        required_ids = [p.id for p in required]
        finished = Score.objects.filter(judge=judge, project_id__in=required_ids).count()
        return finished, len(required)

    @classmethod
    def can_submit(cls, judge, category) -> bool:
        finished, total = cls.progress(judge, category)
        return total > 0 and finished == total


    @classmethod
    def recalculate_submission_status(cls, judge, category):
        """Reconcile a prior submission against the current scoring rules.

        Existing submissions remain locked. Their visible status is derived from
        whether every currently required project has a score. This lets status
        recover in both directions when projects, units, permissions, or
        exclusions change.
        """
        submission = GroupSubmission.objects.filter(judge=judge, category=category).first()
        if not submission:
            return None
        if not JudgeCategoryPermission.objects.filter(judge=judge, category=category).exists():
            return submission

        required_ids = [p.id for p in cls.required_projects(judge, category)]
        scored_ids = set(
            Score.objects.filter(judge=judge, project_id__in=required_ids)
            .values_list('project_id', flat=True)
        )
        has_missing_required_score = any(project_id not in scored_ids for project_id in required_ids)
        new_status = (
            GroupSubmission.STATUS_PENDING
            if has_missing_required_score
            else GroupSubmission.STATUS_SUBMITTED
        )
        update_fields = []
        if submission.status != new_status:
            submission.status = new_status
            update_fields.append('status')
        if update_fields:
            submission.save(update_fields=update_fields)
        return submission

    @classmethod
    def recalculate_category_submissions(cls, category):
        submissions = (
            GroupSubmission.objects.filter(category=category)
            .select_related('judge', 'category')
        )
        for submission in submissions:
            cls.recalculate_submission_status(submission.judge, category)

    @staticmethod
    def submission_status(judge, category) -> str:
        submission = GroupSubmission.objects.filter(judge=judge, category=category).first()
        if not submission:
            return '未提交'
        if submission.status == GroupSubmission.STATUS_PENDING:
            return '待評分'
        return '已提交'
