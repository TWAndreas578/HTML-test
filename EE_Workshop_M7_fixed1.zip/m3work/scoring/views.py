import json

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from contest.models import Category, Project
from .models import GroupSubmission, JudgeCategoryPermission, ManualProjectExclusion, Score
from .rules import RuleEngine


def judge_required(view_func):
    @login_required
    def wrapped(request, *args, **kwargs):
        if not request.user.is_judge_role:
            return render(request, 'accounts/permission_denied.html', status=403)
        return view_func(request, *args, **kwargs)
    return wrapped


@judge_required
def judge_home(request):
    permissions = (
        JudgeCategoryPermission.objects
        .filter(judge=request.user)
        .select_related('category')
        .order_by('category__sort_order', 'category__id')
    )
    cards = []
    for permission in permissions:
        category = permission.category
        RuleEngine.recalculate_submission_status(request.user, category)
        finished, total = RuleEngine.progress(request.user, category)
        submission = GroupSubmission.objects.filter(judge=request.user, category=category).first()
        status = RuleEngine.submission_status(request.user, category)
        is_locked = bool(submission and submission.is_locked)
        display_status = status
        if submission and not is_locked and status == '已提交':
            display_status = '未提交'
        cards.append({
            'category': category,
            'finished': finished,
            'total': total,
            'status': status,
            'display_status': display_status,
            'is_locked': is_locked,
        })
    return render(request, 'judge/home.html', {'cards': cards})


@judge_required
def score_category(request, category_id):
    permission = get_object_or_404(
        JudgeCategoryPermission.objects.select_related('category'),
        judge=request.user,
        category_id=category_id,
    )
    category = permission.category
    RuleEngine.recalculate_submission_status(request.user, category)
    submission = GroupSubmission.objects.filter(judge=request.user, category=category).first()
    projects = list(category.projects.order_by('display_order', 'id'))
    score_map = dict(Score.objects.filter(judge=request.user, project__category=category).values_list('project_id', 'grade'))
    exclusion_ids = set(ManualProjectExclusion.objects.filter(
        judge=request.user, project__category=category, is_excluded=True
    ).values_list('project_id', flat=True))

    rows = []
    for project in projects:
        same_unit = (project.unit or '').strip().casefold() == (request.user.unit or '').strip().casefold()
        manual_excluded = project.id in exclusion_ids
        rows.append({
            'project': project,
            'grade': score_map.get(project.id, ''),
            'same_unit': same_unit,
            'manual_excluded': manual_excluded,
            'can_score': not same_unit and not manual_excluded,
        })
    finished, total = RuleEngine.progress(request.user, category)
    locked = bool(submission and submission.is_locked)
    return render(request, 'judge/score_category.html', {
        'category': category,
        'rows': rows,
        'finished': finished,
        'total': total,
        'locked': locked,
        'status': RuleEngine.submission_status(request.user, category),
    })


def _parse_scores(request):
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({'ok': False, 'error': '資料格式錯誤。'}, status=400)
    scores = payload.get('scores')
    if not isinstance(scores, dict):
        return None, JsonResponse({'ok': False, 'error': '缺少評分資料。'}, status=400)
    return scores, None


@judge_required
@require_POST
def save_scores(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    get_object_or_404(JudgeCategoryPermission, judge=request.user, category=category)
    submission = GroupSubmission.objects.filter(judge=request.user, category=category).first()
    if submission and submission.is_locked:
        return JsonResponse({'ok': False, 'error': '此組別已鎖定。'}, status=423)

    scores, error = _parse_scores(request)
    if error:
        return error
    project_map = {str(p.id): p for p in category.projects.all()}
    valid_grades = {Score.SCORE_A, Score.SCORE_B, Score.SCORE_C}
    with transaction.atomic():
        for project_id, grade in scores.items():
            project = project_map.get(str(project_id))
            if not project or not RuleEngine.project_eligibility(request.user, project).can_score:
                continue
            grade = str(grade).upper().strip()
            if grade in valid_grades:
                Score.objects.update_or_create(
                    judge=request.user, project=project, defaults={'grade': grade}
                )
            elif grade == '':
                Score.objects.filter(judge=request.user, project=project).delete()
    finished, total = RuleEngine.progress(request.user, category)
    return JsonResponse({'ok': True, 'finished': finished, 'total': total})


@judge_required
@require_POST
def submit_scores(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    get_object_or_404(JudgeCategoryPermission, judge=request.user, category=category)
    submission = GroupSubmission.objects.filter(judge=request.user, category=category).first()
    if submission and submission.is_locked:
        return JsonResponse({'ok': False, 'error': '此組別已鎖定。'}, status=423)

    scores, error = _parse_scores(request)
    if error:
        return error
    project_map = {str(p.id): p for p in category.projects.all()}
    valid_grades = {Score.SCORE_A, Score.SCORE_B, Score.SCORE_C}
    with transaction.atomic():
        for project_id, grade in scores.items():
            project = project_map.get(str(project_id))
            if not project or not RuleEngine.project_eligibility(request.user, project).can_score:
                continue
            grade = str(grade).upper().strip()
            if grade in valid_grades:
                Score.objects.update_or_create(judge=request.user, project=project, defaults={'grade': grade})
        if not RuleEngine.can_submit(request.user, category):
            finished, total = RuleEngine.progress(request.user, category)
            return JsonResponse({
                'ok': False,
                'error': f'尚有 {total - finished} 件作品未評分。',
                'finished': finished,
                'total': total,
            }, status=400)
        GroupSubmission.objects.update_or_create(
            judge=request.user,
            category=category,
            defaults={
                'status': GroupSubmission.STATUS_SUBMITTED,
                'is_locked': True,
            },
        )
    return JsonResponse({'ok': True, 'redirect': '/judge/'})
