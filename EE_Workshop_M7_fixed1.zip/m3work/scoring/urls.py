from django.urls import path
from . import views

urlpatterns = [
    path('', views.judge_home, name='judge_home'),
    path('category/<int:category_id>/', views.score_category, name='score_category'),
    path('category/<int:category_id>/save/', views.save_scores, name='save_scores'),
    path('category/<int:category_id>/submit/', views.submit_scores, name='submit_scores'),
]
