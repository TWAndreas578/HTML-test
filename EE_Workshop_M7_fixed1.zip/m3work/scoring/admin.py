from django.contrib import admin
from .models import JudgeCategoryPermission, ManualProjectExclusion, Score, GroupSubmission

admin.site.register(JudgeCategoryPermission)
admin.site.register(ManualProjectExclusion)
admin.site.register(Score)
admin.site.register(GroupSubmission)
